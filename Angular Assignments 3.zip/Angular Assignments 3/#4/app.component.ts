import { Options } from './options';

import {Component, NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})


export class AppComponent {
  
selectedOption:Options = new Options(2, 'T-Shirts',222);
totalPrice:number = 0;

options = [
     new Options(1, 'Jeans' ,111),
     new Options(2, 'T-Shirts' ,222),
     new Options(3, 'Shorts' ,333),
     new Options(4, 'Shirts',444),     
     new Options(5, 'Trousers',555),
     new Options(6, 'Chinos',443),
     new Options(7, 'Shoes',564)
  ];
  
getValue(optionid: number) {
      
this.selectedOption = this.options.filter((item)=> item.id == optionid)[0];
  
}

getSum(index: number) : number {
  if(this.totalPrice!=0){ this.totalPrice=0;}
  for(let i = 0; i < this.options.length; i++) {
    console.log("We are going to add now : "+this.options[i].price);
    this.totalPrice += this.options[i].price;
  }
  return this.totalPrice;
}

}