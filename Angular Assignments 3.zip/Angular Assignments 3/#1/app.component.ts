import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <a [routerLink]="['/']">Home</a>&nbsp;&nbsp;
    <a [routerLink]="['/about']">About</a>&nbsp;&nbsp;
    <a [routerLink]="['/help']">Help</a>&nbsp;&nbsp;
    <a [routerLink]="['/security']">Security</a>&nbsp;&nbsp;
    <a [routerLink]="['/contactus']">ContactUs</a>
    <div>
      <router-outlet></router-outlet>
    </div>
  `
})
export class AppComponent { }